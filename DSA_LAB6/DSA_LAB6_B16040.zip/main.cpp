#include <bits/stdc++.h>
#include "BSTree.hpp"
using namespace std;

int main(){
	BSTree<int,int> tree;
	tree.put(4,10);
	tree.put(2,10);
	// cout<<tree.size()<<endl;

	return 0;
}