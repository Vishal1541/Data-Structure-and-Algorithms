#include <bits/stdc++.h>
#include "List.hpp"

using namespace std;

int main(){
	list<int> l;
	cout<<l.length()<<l.empty()<<endl;
	l.append(12);l.append(34);l.append(11);
	cout<<l.length()<<l.empty()<<endl;
	l.cons(45);
	cout<<l.length()<<l.empty()<<endl;
	l.remove(45);
	cout<<l.length()<<l.empty()<<endl;
	l.remove(11);
	cout<<l.length()<<l.empty()<<endl;

	return 0;
}